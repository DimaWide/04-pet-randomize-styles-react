
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
// import Header from './components/Header';
import TodoApp from './components/ToDoApp';

const App = () => {
    return (
        <div>
            <TodoApp />
        </div>
    );
};

export default App;
