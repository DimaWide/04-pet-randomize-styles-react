import React, { useState } from 'react';
import { Slider, Space, Button } from 'antd';

// Функция для генерации случайных чисел в заданном диапазоне
const getRandomInRange = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// Функция для генерации случайного пастельного цвета в формате HSL
const getRandomPastelColor = (hueRange, saturationRange, lightnessRange) => {
    const h = getRandomInRange(hueRange[0], hueRange[1]);
    const s = getRandomInRange(saturationRange[0], saturationRange[1]);
    const l = getRandomInRange(lightnessRange[0], lightnessRange[1]);
    return `hsl(${h}, ${s}%, ${l}%)`;
};

// Функция для добавления стилей в документ
const addGlobalStyles = (backgroundColor1, buttonColor1, backgroundColor2, buttonColor2) => {
    const style = document.createElement('style');
    style.innerHTML = `
        body {
            background-color: ${backgroundColor2};
        }

        .todo-app {
            background-color: ${backgroundColor1};
            font-family: Arial, sans-serif;
            font-size: 18px;
            padding: 15px;
            max-width: 600px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .todo-app__title {
            color: ${buttonColor1};
        }

        .todo-app__input input {
            background-color: #e6e6e6;
            border-color: #d1d1d1;
            color: ${buttonColor1};
        }

        .todo-app__filters button {
            background-color: ${buttonColor1};
            border-color: #ccc;
            color: #fff;
        }

        .todo-app__list .ant-list-item {
            background-color: ${backgroundColor1};
            border-radius: 8px;
            margin-bottom: 10px;
            padding: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .ant-btn-primary {
            background-color: ${buttonColor1};
            border-color: ${buttonColor1};
            color: white;
        }
    `;
    document.head.appendChild(style);
};

const Randomizer = () => {
    // Состояния для первого набора цветов
    const [hueRange1, setHueRange1] = useState([0, 280]);
    const [saturationRange1, setSaturationRange1] = useState([30, 80]);
    const [lightnessRange1, setLightnessRange1] = useState([20, 90]);

    // Состояния для второго набора цветов
    const [hueRange2, setHueRange2] = useState([0, 280]);
    const [saturationRange2, setSaturationRange2] = useState([30, 80]);
    const [lightnessRange2, setLightnessRange2] = useState([20, 90]);

    // Функция, которая срабатывает при изменении стилей
    const handleStyleChange = () => {
        const backgroundColor1 = getRandomPastelColor(hueRange1, saturationRange1, lightnessRange1);
        const buttonColor1 = getRandomPastelColor(hueRange1, saturationRange1, lightnessRange1);
        const backgroundColor2 = getRandomPastelColor(hueRange2, saturationRange2, lightnessRange2);
        const buttonColor2 = getRandomPastelColor(hueRange2, saturationRange2, lightnessRange2);
        
        // Добавляем стили в документ
        addGlobalStyles(backgroundColor1, buttonColor1, backgroundColor2, buttonColor2);
    };

    // Функция для получения цветов крайних значений
    const previewColor1Left = getRandomPastelColor([hueRange1[0], hueRange1[0]], [saturationRange1[0], saturationRange1[0]], [lightnessRange1[0], lightnessRange1[0]]);
    const previewColor1Right = getRandomPastelColor([hueRange1[1], hueRange1[1]], [saturationRange1[1], saturationRange1[1]], [lightnessRange1[1], lightnessRange1[1]]);

    const previewColor2Left = getRandomPastelColor([hueRange2[0], hueRange2[0]], [saturationRange2[0], saturationRange2[0]], [lightnessRange2[0], lightnessRange2[0]]);
    const previewColor2Right = getRandomPastelColor([hueRange2[1], hueRange2[1]], [saturationRange2[1], saturationRange2[1]], [lightnessRange2[1], lightnessRange2[1]]);

    return (
        <div className='cpt-rand'>
            <h3>Adjust Color Settings for Color 1</h3>
            <Space direction="vertical" style={{ width: '100%' }}>
                <div>
                    <p>Hue Range:</p>
                    <Slider
                        range
                        min={0}
                        max={360}
                        value={hueRange1}
                        onChange={setHueRange1}
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ backgroundColor: previewColor1Left, width: '30px', height: '30px', borderRadius: '4px' }} />
                        <div style={{ backgroundColor: previewColor1Right, width: '30px', height: '30px', borderRadius: '4px' }} />
                    </div>
                </div>
                <div>
                    <p>Saturation Range:</p>
                    <Slider
                        range
                        min={0}
                        max={100}
                        value={saturationRange1}
                        onChange={setSaturationRange1}
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ backgroundColor: previewColor1Left, width: '30px', height: '30px', borderRadius: '4px' }} />
                        <div style={{ backgroundColor: previewColor1Right, width: '30px', height: '30px', borderRadius: '4px' }} />
                    </div>
                </div>
                <div>
                    <p>Lightness Range:</p>
                    <Slider
                        range
                        min={0}
                        max={100}
                        value={lightnessRange1}
                        onChange={setLightnessRange1}
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ backgroundColor: previewColor1Left, width: '30px', height: '30px', borderRadius: '4px' }} />
                        <div style={{ backgroundColor: previewColor1Right, width: '30px', height: '30px', borderRadius: '4px' }} />
                    </div>
                </div>
            </Space>

            <h3>Adjust Color Settings for Color 2</h3>
            <Space direction="vertical" style={{ width: '100%' }}>
                <div>
                    <p>Hue Range:</p>
                    <Slider
                        range
                        min={0}
                        max={360}
                        value={hueRange2}
                        onChange={setHueRange2}
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ backgroundColor: previewColor2Left, width: '30px', height: '30px', borderRadius: '4px' }} />
                        <div style={{ backgroundColor: previewColor2Right, width: '30px', height: '30px', borderRadius: '4px' }} />
                    </div>
                </div>
                <div>
                    <p>Saturation Range:</p>
                    <Slider
                        range
                        min={0}
                        max={100}
                        value={saturationRange2}
                        onChange={setSaturationRange2}
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ backgroundColor: previewColor2Left, width: '30px', height: '30px', borderRadius: '4px' }} />
                        <div style={{ backgroundColor: previewColor2Right, width: '30px', height: '30px', borderRadius: '4px' }} />
                    </div>
                </div>
                <div>
                    <p>Lightness Range:</p>
                    <Slider
                        range
                        min={0}
                        max={100}
                        value={lightnessRange2}
                        onChange={setLightnessRange2}
                    />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ backgroundColor: previewColor2Left, width: '30px', height: '30px', borderRadius: '4px' }} />
                        <div style={{ backgroundColor: previewColor2Right, width: '30px', height: '30px', borderRadius: '4px' }} />
                    </div>
                </div>
            </Space>

            <Button type="primary" onClick={handleStyleChange}>Generate Colors</Button>
        </div>
    );
};

export default Randomizer;
