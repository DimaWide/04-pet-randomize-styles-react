import React, { useState, useEffect } from 'react';
import { Button, Checkbox, Input, List, Space, message } from 'antd';
import Randomizer from './Randomizer';

const App = () => {
    const [tasks, setTasks] = useState([]);
    const [newTask, setNewTask] = useState('');
    const [filter, setFilter] = useState('all');

    // Загружаем задачи из localStorage при монтировании компонента
    useEffect(() => {
        const storedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
        setTasks(storedTasks);
    }, []);

    // Сохраняем задачи в localStorage при их изменении
    useEffect(() => {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }, [tasks]);

    const addTask = () => {
        if (newTask.trim() === '') return;

        const task = { title: newTask, completed: false };
        setTasks(prevTasks => [...prevTasks, task]);
        setNewTask('');
    };

    const toggleComplete = (taskId) => {
        const updatedTasks = tasks.map((task, index) => 
            index === taskId ? { ...task, completed: !task.completed } : task
        );
        setTasks(updatedTasks);
    };

    const deleteTask = (taskId) => {
        const updatedTasks = tasks.filter((_, index) => index !== taskId);
        setTasks(updatedTasks);
    };

    const filteredTasks = tasks.filter(task => {
        if (filter === 'completed') return task.completed;
        if (filter === 'incomplete') return !task.completed;
        return true; // Default: return all tasks
    });

    const completedCount = tasks.filter(task => task.completed).length;
    const remainingCount = tasks.length - completedCount;

    return (
        <div className="todo-app-out">
            <Randomizer></Randomizer>
            <div className="todo-app" style={{ maxWidth: 600, margin: '0 auto', padding: 20 }}>
                <h1 className="todo-app__title">Todo App</h1>
                <div className="todo-app__input">
                    <Input
                        value={newTask}
                        onChange={(e) => setNewTask(e.target.value)}
                        placeholder="Enter a new task"
                        style={{ width: 'calc(100% - 80px)', marginBottom: 10 }}
                    />
                    <Button type="primary" onClick={addTask} style={{ width: 80 }}>
                        Add
                    </Button>
                </div>

                <div className="todo-app__filters" style={{ margin: '10px 0' }}>
                    <Button type={filter === 'all' ? 'default' : 'text'} onClick={() => setFilter('all')}>
                        All
                    </Button>
                    <Button type={filter === 'completed' ? 'default' : 'text'} onClick={() => setFilter('completed')}>
                        Completed
                    </Button>
                    <Button type={filter === 'incomplete' ? 'default' : 'text'} onClick={() => setFilter('incomplete')}>
                        Incomplete
                    </Button>
                </div>

                <div className="todo-app__counts">
                    <Space>
                        <span>Remaining tasks: {remainingCount}</span>
                        <span>Completed tasks: {completedCount}</span>
                    </Space>
                </div>

                <List
                    dataSource={filteredTasks}
                    renderItem={(task, index) => (
                        <List.Item key={index} actions={[
                            <Button onClick={() => toggleComplete(index)}>
                                {task.completed ? 'Mark as Incomplete' : 'Mark as Completed'}
                            </Button>,
                            <Button danger onClick={() => deleteTask(index)}>Delete</Button>
                        ]}>
                            <List.Item.Meta
                                avatar={<Checkbox checked={task.completed} onChange={() => toggleComplete(index)} />}
                                title={task.title}
                            />
                        </List.Item>
                    )}
                />
            </div>
        </div>
    );
};

export default App;
